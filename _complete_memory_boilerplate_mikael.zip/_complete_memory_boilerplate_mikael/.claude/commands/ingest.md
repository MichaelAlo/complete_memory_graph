# Ingest a new source into the wiki.

The user has provided a file path in raw/ after the /ingest command.

Execute in order:

1. Read the source file the user specified
2. Discuss with the user: what are the 3-5 key takeaways from this source?
3. Write a summary page to wiki/summaries/[source-name].md with:
   - Source title and origin
   - Date ingested
   - Key takeaways (bullet list)
   - Link back to the raw file
4. Update or create relevant pages in wiki/concepts/ and wiki/entities/
   based on what the source covers
5. Update wiki/index.md: add the new summary page and any new concept/entity pages
6. If any content contradicts existing wiki pages, flag the contradiction explicitly
   and ask the user how to resolve it
7. Confirm: "Ingest complete. Created [N] pages, updated [M] existing pages."