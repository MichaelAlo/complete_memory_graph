You are resuming a work session on this project.

Execute the following steps in order:

1. Read CLAUDE.md
2. Read context/worklog.md
3. Read the most recent file in context/session-summaries/ (sort by filename date descending)
4. Read context/decisions.md (last 3 entries only)

Then respond with:
- **Current objective:** [from worklog]
- **Last session summary:** [key points from session summary]
- **Active branch/spec:** [from worklog]
- **Next actions:** [from worklog]
- **Open questions:** [from worklog]
- **Recent decisions:** [last 3 from decisions.md]

Do not start working yet. Wait for my instruction.