# Perform a health check on the wiki.

Read wiki/index.md to get a full map of all pages, then check for:

1. **Contradictions** — claims on different pages that conflict with each other
2. **Stale claims** — content that newer sources in raw/ may have superseded
3. **Orphan pages** — pages with no inbound links from other wiki pages
4. **Missing pages** — important concepts mentioned across pages but lacking their own page
5. **Missing cross-references** — pages that should link to each other but don't
6. **Data gaps** — topics that appear frequently but have thin coverage

Report findings in this format:
## Wiki Lint Report — [DATE]
### Contradictions
### Stale claims
### Orphan pages
### Missing pages
### Missing cross-references
### Data gaps
### Summary: [N] issues found

Then ask: "Which of these should I fix now?"