End-of-session checkpoint. Execute the following:

1. Read context/worklog.md
2. Based on this session's work, write a session summary to:
   context/session-summaries/YYYY-MM-DD.md (use today's actual date)

   Summary format:
   ## Done this session
   - [bullet list of completed items]

   ## Decisions made
   - [any decisions, or "none"]

   ## Current state
   [one paragraph describing where things stand]

   ## Next actions
   1. [first]
   2. [second]
   3. [third]

   ## Open questions
   - [unresolved items, or "none"]

3. Update context/worklog.md:
   - Move completed items to "Done (recent)"
   - Set "Next actions" to match the summary above
   - Update "Current state" date and objective
   - Update "Open questions"

4. If any architectural changes were made this session, ask me:
   "Should I update context/architecture.md to reflect [specific change]?"

5. Confirm: "Checkpoint complete. Summary written to context/session-summaries/[date].md"