Log a decision to the decisions file.

The user has provided a decision in their message after the /decision command.

1. Read context/decisions.md
2. Append a new entry at the bottom using this format:

---
### [TODAY'S DATE] [Short title derived from the decision]
**Decision:** [The decision the user stated]
**Rationale:** [Ask me for rationale if not provided, otherwise use what was given]
**Consequences:** [Infer the main consequences, or ask if unclear]
---

3. Confirm: "Decision logged to context/decisions.md"